from django.urls import path
from . import views 
from django.contrib.auth import views as auth_views

app_name = 'settings'

urlpatterns = [
    path('', views.return_settings_page, name='settings_page'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout_user'),
    path('edit_contact', views.edit_emergency_contact, name='edit_contact'),
    path('delete_contact', views.delete_emergency_contact, name='delete_contact'),
    path('edit_profile', views.edit_profile, name='edit_profile'),
    path('delete_user',  views.delete_user, name='delete_user'), 
    path('edit_password', views.edit_password, name='edit_password'),
]