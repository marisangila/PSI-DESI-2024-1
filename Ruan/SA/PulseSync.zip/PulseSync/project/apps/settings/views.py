from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from ..register_user.models import UserDatas
from .models import Emergency_contact
from django.http.response import HttpResponse
from .forms import EmergencyContactForm, UserForm, UserDatasForm, UserPassword
from ..register_user.views import correctFormatPhone, correctFormatCpf ,validationlengthMinAndMax

def return_settings_datas_user(request):
    user = User.objects.get(pk=request.user.id)
    user_datas = UserDatas.objects.get(fk_user_id = request.user.id)
    user_datas.cpf_user = set_cpf_format(user_datas.cpf_user)
    user_datas.phone_number_user = user_datas.phone_number_user
    try:
        emergency_contact = Emergency_contact.objects.get(fk_user_id = request.user.id)
        emergency_contact.phone_number_contact = emergency_contact.phone_number_contact
        return {'page':'settings', 'user':user, 'user_datas':user_datas, 'emergency_contact':emergency_contact}
    except:
        return {'page': 'settings', 'user':user, 'user_datas':user_datas}


@login_required
def return_settings_page(request):
    form_datas = return_settings_datas_user(request)
    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})


@login_required
def edit_emergency_contact(request):
    if request.method == 'POST':
        try:
            form = EmergencyContactForm(request.POST)
            if form.is_valid():
                emergency_contact_exists = Emergency_contact.objects.filter(fk_user_id_id=request.user.id).exists()
                if emergency_contact_exists:
                    emergency_contact = Emergency_contact.objects.get(fk_user_id_id = request.user.id)
                    validatedPhone = validationlengthMinAndMax(request, 'phone_number_contact', 11, 11)
                    if validatedPhone == False:
                        emergency_contact.phone_number_contact =  form.cleaned_data['phone_number_contact']
                    else:
                        form_datas = return_settings_datas_user(request)
                        return render(request,'settings/pages/settings.html', {'phoneError':True, 'form_datas':form_datas})
                    emergency_contact.full_name_contact = form.cleaned_data['full_name_contact']
                    emergency_contact.email_contact = form.cleaned_data['email_contact']
                    emergency_contact.save() 
                else:
                    emergency_contact = form.save(commit=False)
                    emergency_contact.fk_user_id_id = request.user.id
                    onlyNumbersPhone = correctFormatPhone(emergency_contact.phone_number_contact)
                    emergency_contact.phone_number_contact = onlyNumbersPhone
                    emergency_contact.save()
                    form_datas = return_settings_datas_user(request)
                    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})
            else:
                print('formulário inválido!!')
                for errorList in form.errors.values():
                    for error in errorList:
                        print(f"\nErro: {error}\n\n")
                form_datas = return_settings_datas_user(request)
                formError = {
                    'phoneError': validationlengthMinAndMax(request, 'phone_number_contact', 11, 11)
                }
                return render(request, 'settings/pages/settings.html', formError)
            
        except Exception as e:
            print(f'ERRO: {e}')
    form_datas = return_settings_datas_user(request)
    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})


@login_required
def delete_emergency_contact(request):
    if request.method == "POST":
        try:
            emergency_contact_exists = Emergency_contact.objects.filter(fk_user_id_id = request.user.id).exists()
            if emergency_contact_exists:
                emergency_contact = Emergency_contact.objects.get(fk_user_id_id = request.user.id)
                emergency_contact.delete()
        except Exception as e:
            print(f'ERRO {e}')
    form_datas = return_settings_datas_user(request)
    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})


@login_required
def edit_profile(request):
    if request.method == "POST":
        try:
            form_user = UserForm(request.POST)
            form_user_datas = UserDatasForm(request.POST)
            if form_user.is_valid() and form_user_datas.is_valid():
                user = User.objects.get(pk = request.user.id)
                user.username = form_user.cleaned_data['username']
                user.email = form_user.cleaned_data['email']
                user.save()

                user_datas = UserDatas.objects.get(fk_user_id = request.user.id)
                user_datas.birth_user = form_user_datas.cleaned_data['birth_user']
                
                #validar o cpf
                if len(correctFormatCpf(form_user_datas.cleaned_data['cpf_user'])) == 11:
                    user_datas.cpf_user = correctFormatCpf(form_user_datas.cleaned_data['cpf_user'])
                else:
                    form_datas = return_settings_datas_user(request)
                    return render(request,'settings/pages/settings.html', {'cpfError':True, 'form_datas':form_datas})
                
                #validar telefone
                if len(correctFormatPhone(form_user_datas.cleaned_data['phone_number_user'])) == 11:
                    print("\nEntrou na parte de cima\n")
                    user_datas.phone_number_user =  correctFormatPhone(form_user_datas.cleaned_data['phone_number_user'])
                else:
                    print("\nEntrou na parte de baixo\n")
                    form_datas = return_settings_datas_user(request)
                    return render(request,'settings/pages/settings.html', {'phoneProfileError':True, 'form_datas':form_datas})
                
                if form_user_datas.cleaned_data['cardiac_problem_user'] == 'Yes':
                    user_datas.cardiac_problem_user = True
                elif form_user_datas.cleaned_data['cardiac_problem_user'] == 'No':
                    user_datas.cardiac_problem_user = False
                user_datas.save()
                #form_datas = return_settings_datas_user(request) 
                #return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})
            else:
                print('formulário inválido')#remover else depois de finalizada os logs de erro
        except Exception as e:
            print(f'ERRO {e}')
    form_datas = return_settings_datas_user(request)
    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})


@login_required
def delete_user(request):
    if request.method == "POST":
        try:
            user =  User.objects.get(pk = request.user.id)
            user.delete()
            return redirect('login_user:login_page')
        except Exception as e:
            print(f"ERRO {e}")
    form_datas = return_settings_datas_user(request)
    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})


@login_required
def edit_password(request):
    if request.method == "POST":
        form =  UserPassword(request.POST)
        if form.is_valid():
            if form.cleaned_data['password'] == request.POST['confirm-password']:
                user = get_object_or_404(User, id=request.user.id)
                user.set_password(form.cleaned_data['password'])
                user.save()
            else:
                print('Incorrect password!')
                form_datas = return_settings_datas_user(request)
                return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})
        else:
            print('senha inválida!!!')
    form_datas = return_settings_datas_user(request)
    return render(request, 'settings/pages/settings.html', {'form_datas':form_datas})


def set_cpf_format(cpf):
    if(len(cpf) == 11 or len(cpf) == 15):
        correctCpf = ""
        for i in range(len(cpf)):
            letter = cpf[i]
            if((i+1) == 9): correctCpf += (str(letter) + '-')
            elif((i+1) % 3 == 0 and i != 0): correctCpf += (str(letter) + '.')
            else: correctCpf += letter
    else:
        correctCpf = cpf
    return correctCpf


# def set_phone_number_user(number):
#     result_of_formatting = '('
#     for i in range(len(number)):
#         if i == 1: result_of_formatting += f'{number[i]}) '
#         elif i == 6: result_of_formatting += f'{number[i]}-'
#         else: result_of_formatting += number[i]
#     return result_of_formatting
    
# def validate_len_phone_if_contact_not_exists(phone):
#     if (len(phone) != 11):
#         return True
#     else:
#         return False
