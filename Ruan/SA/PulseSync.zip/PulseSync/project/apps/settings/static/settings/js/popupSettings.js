export function openClosePopUpPassword(openOrClose){
    if(openOrClose){
        $('.popup-base').css('display', 'flex');
        $('#popups-settings-password').css('display', 'flex');
    }else{
        $('.popup-base').css('display', 'none');
        $('#popups-settings-password').css('display', 'none');
    };
};