import * as popupSettings from './popupSettings.js';

$(document).ready(()=>{
    
    if(window.matchMedia("(max-width: 415px)").matches){
        $("#editPasswordBtn").prop('value', 'Edit psw');
    };

    $('.btn-emergency-form').on('click', function(){
        let data = $(this).data('button');
        if(data === 'edit'){
            let form = $('#emergency-contact-form').attr('action', '/settings/edit_contact');
            form.submit();
        }else if(data === 'delete'){
            let form = $('#emergency-contact-form').attr('action', '/settings/delete_contact');
            form.submit();
        };
    });

    $('.btn-profile-form').on('click', function(){
        let data = $(this).data('button');
        if(data === 'edit'){
            let form = $('#profile-form').attr('action', '/settings/edit_profile');
            form.submit();
        }else if(data === 'delete'){
            let form = $('#profile-form').attr('action', '/settings/delete_user');
            form.submit();
        }else if(data === 'edit-password'){
            popupSettings.openClosePopUpPassword(true);
        };
    });

    $('#cancel-password').on('click', ()=>{
        popupSettings.openClosePopUpPassword(false);
    });

    // $('#confirm-password').on('click', ()=>{
    //     let form = $('#profile-form').attr('action', '/settings/edit_password');
    //     form.submit();
    // });
});