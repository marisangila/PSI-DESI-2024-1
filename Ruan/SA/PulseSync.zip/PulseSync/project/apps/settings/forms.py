from django import forms
from .models import Emergency_contact
from django.contrib.auth.models import User
from ..register_user.models import UserDatas

class EmergencyContactForm(forms.ModelForm):
    class Meta:
        model = Emergency_contact
        fields = ['full_name_contact', 'phone_number_contact', 'email_contact']


class UserForm(forms.Form):
    username = forms.CharField(max_length=50, required=True)
    email = forms.EmailField(max_length=50, required=True)


class UserDatasForm(forms.Form):
    cpf_user = forms.CharField(max_length=20, required=True)
    birth_user = forms.DateField(required=True)
    phone_number_user = forms.CharField(required=True)
    cardiac_problem_user = forms.CharField(required=True, max_length=6)


class UserPassword(forms.ModelForm):
    class Meta:
        model = User
        fields = ['password']