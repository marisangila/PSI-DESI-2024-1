from django.db import models
from apps.register_user.models import User

class Emergency_contact(models.Model):
    full_name_contact = models.CharField(max_length=100, blank=True)
    email_contact = models.CharField(max_length=100, blank=True)
    phone_number_contact = models.CharField(max_length=15, blank=True)
    fk_user_id = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.full_name_contact
