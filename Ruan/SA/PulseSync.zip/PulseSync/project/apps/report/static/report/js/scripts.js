// $(document).ready(()=>{
//    console.log("Btataatat")
//    console.log($('#input-date').value());
// });


// $("#first_date_input").on('change', () => {
//    let date = $("#first_date_input").val()
//    let csrf_token = $(document).find('[name=csrfmiddlewaretoken]').val();
//    $.ajax({
//       url: 'historic_date',
//       type: 'POST',
//       data: {
//          'data': date,
//          'csrfmiddlewaretoken': csrf_token
//       }
//   });
// })