from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def getDate(request):
    if request.method == 'POST':
        date = request.POST.get('data')
        print(f"\nDate: {date}\n")
        return render(request, 'report/pages/report.html', {'date':date})
    return render(request, 'report/pages/report.html')

@login_required
def return_report_page(request):
    return render(request, 'report/pages/report.html', {'page': 'report', 'len': range(20)})