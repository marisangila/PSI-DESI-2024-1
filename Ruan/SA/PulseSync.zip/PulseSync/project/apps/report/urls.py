from django.urls import path
from . import views

app_name = 'report'

urlpatterns = [
    path('', views.return_report_page, name='report_page'),
    path('historic_date', views.getDate, name='getDate'),
]