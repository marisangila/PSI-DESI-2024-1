from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import FormLogin
from django.contrib.auth.models import User

def return_login_page(request):
    return render(request, 'login/pages/login.html')

def login_user(request):
    if request.method == "POST":
        forms = FormLogin(request.POST)
    
        if forms.is_valid():
            email = forms.cleaned_data.get('email')
            try:
                User.objects.get(email = email)
            except:
                return render(request, 'login/pages/login.html', {'form_datas': request.POST, 'emailInvalid': True, 'error': False})
            password = forms.cleaned_data.get('password')

            user = authenticate(request, email=email, password=password)
            if user:
                login(request, user)
                return redirect('home:home_page')
            
    return render(request, 'login/pages/login.html', {'form_datas': request.POST, 'error': True})