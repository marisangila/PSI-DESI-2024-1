from celery import shared_task
import asyncio 
from django.core.cache import cache
import os, django
import bleak, serial
from ..register_user.models import UserDatas
from .models import Report
from asgiref.sync import sync_to_async
from datetime import datetime


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pulsesync.settings')
django.setup()


async def run_async_def(user_id):
    async def verify_connection(user_id):
        try:
            while True:
                user_connect = await sync_to_async(UserDatas.objects.get)(fk_user_id=user_id)
                connect_sensor = await sync_to_async(lambda: user_connect.connect_sensor, thread_sensitive=True)()
                if connect_sensor:
                    try:
                        await asyncio.sleep(60)
                    except Exception as error:
                        return error
                else:
                    return 'closed connection'
        except Exception as ex:
            return str(ex)
    
    possible_erros = await verify_connection(user_id)
    return possible_erros


@shared_task
def colect_datas(user_id):
    return_possible_errors = asyncio.run(run_async_def(user_id))
    if return_possible_errors:
        print(return_possible_errors)
        return return_possible_errors
    return 'Closed connection'

"""
async def run_async_def(user_id):
    async def verify_connection(user_id):
        # serial_port = None
        try:
            # serial_port = serial.Serial(
            #     port='/dev/ttyS2',
            #     baudrate=9600,
            #     bytesize=serial.EIGHTBITS,
            #     parity=serial.PARITY_NONE,
            #     stopbits=serial.STOPBITS_ONE,
            #     timeout=1
            # )
            # print(f'Connection with port {serial_port}')

            while True:
                user_connect = await sync_to_async(UserDatas.objects.get)(fk_user_id=user_id)
                connect_sensor = await sync_to_async(lambda: user_connect.connect_sensor, thread_sensitive=True)()
                if connect_sensor:
                    try:
                        # if serial_port.in_waiting > 0:
                        #     row = serial_port.readline().decode('utf-8').rstrip()
                        #     print(f'teste {row}')
                        # date = datetime.today().date()
                        # time = datetime.today().time('%H:%M')
                        # print(date)
                        # print(time)
                        # user_instance = await sync_to_async(UserDatas.objects.get)(fk_user_id=user_id)
                        # report = Report(bpm_report=95, date_report=date, time_report=time, fk_user=user_instance)
                        # report.save()
                        await asyncio.sleep(60)
                    except Exception as error:
                        # if serial_port:
                        #     serial_port.close()
                        return error
                else:
                    # if serial_port:
                    #     serial_port.close()
                    return 'closed connection'
        # except serial.SerialException as e:
            # if serial_port:
            #     serial_port.close()
            # return str(e)
        except Exception as ex:
            # if serial_port:
            #     serial_port.close()
            return str(ex)
    
    possible_erros = await verify_connection(user_id)
    return possible_erros
"""
