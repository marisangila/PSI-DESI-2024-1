from django.db import models
from apps.register_user.models import User

class Report(models.Model):
    bpm_report = models.IntegerField()
    date_report = models.DateField()
    time_report = models.TimeField()
    fk_user = models.ForeignKey(User, on_delete=models.CASCADE)
