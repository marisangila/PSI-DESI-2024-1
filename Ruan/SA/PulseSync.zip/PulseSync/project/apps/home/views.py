from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .tasks import colect_datas
import asyncio
from django.core.cache import cache, caches
from django.http.response import HttpResponse
from ..register_user.models import UserDatas


@login_required
def return_home_page(request):
    user = UserDatas.objects.get(fk_user_id = request.user.id)
    return render(request, 'home/pages/home.html', {'page': 'home', 'connect': user.connect_sensor})

@login_required
def alter_status(request):
    if request.method == "POST":
        user = UserDatas.objects.get(fk_user_id = request.user.id)
        try:
            if(request.POST['start-monitor'] == 'on'):
                user.connect_sensor = 1
                user.save()
                # colect_datas.delay(request.user.id)
                return HttpResponse('Connect!')
        except:
            pass
        user.connect_sensor = 0
        user.save()
        return HttpResponse('Desconnect!')
