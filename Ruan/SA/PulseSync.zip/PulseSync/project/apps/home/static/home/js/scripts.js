$(document).ready(()=> {
    $('#start-monitor').on('click', ()=>{
        form = $("#monitor")[0];
        formData = new FormData(form)
        let token = $(document).find('[name=csrfmiddlewaretoken]').val();
        $.ajax({
            url:form.action,
            type:'POST',
            data: formData,
            contentType: false,
            processData: false,
            success:(response)=>{
                console.log(`Response: ${response}`);
            },
            error:(xhr, error)=>{
                console.log(`Error: ${error}`);
            }
        });

    });
});