from django.urls import path
from . import views

app_name = 'home'

urlpatterns = [
    path('', views.return_home_page, name='home_page'),
    path('alter_status', views.alter_status, name='alter_status'),
]