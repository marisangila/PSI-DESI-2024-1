from django.urls import path
from . import views

app_name = 'register_user'

urlpatterns = [
    path('', views.return_register_page, name='register_page'),
    path('register_user/', views.createUser, name='createUser'),
]
