from django.shortcuts import redirect, render
from .forms import FormUser, FormDatas
from .models import UserDatas
from django.contrib.auth.models import User

def return_register_page(request):
    return render(request, 'register/pages/register.html', {'first_register':True})


def createUser(request):
    if request.method == "POST": 
        try:
            form_user = FormUser(request.POST)
            form_datas_user = FormDatas(request.POST)

            if form_datas_user.is_valid() and form_user.is_valid():
                if (request.POST.get('password') == request.POST.get('confirmPassword')):
                    if (validate_email_domain(request.POST.get('email'))):
                        createdUser = getUserByEmail(request)
                        if createdUser: 
                            return render(request, 'register/pages/register.html', {'form_datas': request.POST, 'first_register':False, 'created_user':True})
                        try:
                            confirm_cardiac_problem = request.POST.get('cardiac_problem_user') == 'on'
                            if(request.POST.get('confirm_data_user') == 'on'): confirm_data = True
                            else: 
                                confirm_data = False
                                return redirect('register:register_user')
                            
                            user = form_user.save(commit=False)
                            user.set_password(form_user.cleaned_data['password1'])
                            user.save()
                            
                            datas = UserDatas(
                                cpf_user = correctFormatCpf(form_datas_user.cleaned_data['cpf_user']),
                                birth_user = form_datas_user.cleaned_data['birth_user'],
                                phone_number_user = correctFormatPhone(form_datas_user.cleaned_data['phone_number_user']),
                                cardiac_problem_user = confirm_cardiac_problem,
                                confirm_data_user = confirm_data,
                                fk_user_id = user.id
                            )
                            print(f"\nBotão: {datas.confirm_data_user}\n")
                            datas.save()

                            return redirect('login_user:login_page')

                        except Exception as ex:
                            print(f'ERRO AO SALVAR NO BANCO: {ex}')
                            return render(request, 'register/pages/register.html', {'form_datas': request.POST, 'first_register':False})
                    else:
                        return render(request, 'register/pages/register.html', {'form_datas': request.POST, 'domain_email_incorrect': True})                            
                else:
                    return render(request, 'register/pages/register.html', {'form_datas': request.POST})
            else:
                for errorList in form_user.errors.values():
                    for error in errorList:
                        errorEmailAndPassword = True
                        errorDjango = error
                        
                print(f"\nErro: {errorDjango}\n")

                form = {
                    'form_datas': request.POST,
                    'first_register':False,
                    'erro': True,
                    'erroLenUsername': validationlengthMax(request, 'username', 50),
                    'erroLenCpf': validationlengthMinAndMax(request, 'cpf_user', 11, 14),
                    'erroLenBirth': validationlengthMax(request, 'birth_user', 50),
                    'erroLenEmail': validationlengthMax(request, 'email', 50),
                    'erroLenPhone': validationlengthMinAndMax(request, 'phone_number_user', 10, 20),
                    'erroLenPassword': validationlengthMinAndMax(request, 'password1', 8, 20),
                    'errorEmailAndPassword': errorEmailAndPassword,
                    'errorDjango': errorDjango
                }
                return render(request, 'register/pages/register.html', form)    

        except Exception as e:
            print (f"ERRO: {e}")
            return render(request, 'register/pages/register.html', {'form_datas': request.POST, 'first_register':False})

def getUserByEmail(request):
    try:
        return User.objects.get(email = request.POST.get('email'))
    except:
        return False
    
def validate_email_domain(email):
    allowed_domains = ['gmail.com', 'outlook.com', 'yahoo.com']

    try:
        domain = email.split('@')[1].lower()
        if domain in allowed_domains:
            return True
        else:
            return False
    except IndexError:
        return False

def correctFormatPhone(phone):
    phone = phone.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    
    return phone

def correctFormatCpf(cpf):
    cpf = cpf.replace(" ", "").replace(".", "").replace("-", "")
    
    return cpf

def validationlengthMin(request, inputName, charlengthMin):
    if(len(request.POST.get(inputName)) < charlengthMin):
        return True
    return False

def validationlengthMax(request, inputName, charlengthMax):
    if(len(request.POST.get(inputName)) > charlengthMax):
        return True
    return False

def validationlengthMinAndMax(request, inputName, charlengthMin, charlengthMax):
    if(len(request.POST.get(inputName)) < charlengthMin or len(request.POST.get(inputName)) > charlengthMax):
        return True
    return False