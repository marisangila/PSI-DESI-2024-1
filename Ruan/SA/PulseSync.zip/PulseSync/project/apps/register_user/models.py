from django.db import models
from django.contrib.auth.models import User

class UserDatas(models.Model):
    cpf_user = models.CharField(max_length=100, blank=False, null=False)
    birth_user = models.DateField(null=False)
    phone_number_user = models.CharField(max_length=20, blank=False, null=False)
    cardiac_problem_user = models.BooleanField(null=True)
    confirm_data_user = models.BooleanField(null=True)
    connect_sensor = models.BooleanField(default=False, null=True)
    fk_user = models.OneToOneField(User, null=False, default=1, on_delete=models.CASCADE)

    def __str__(self):
        return self.fk_user.username