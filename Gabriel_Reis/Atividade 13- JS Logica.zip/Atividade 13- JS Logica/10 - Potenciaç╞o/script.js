a = Number(prompt("Informe a base:"))
b = Number(prompt("Informe o expoente:"))

alert(`O resultado é: ${result=a**b}`)
