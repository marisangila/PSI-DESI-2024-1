a = Number(prompt("Informe o primeiro numero:"))
b = Number(prompt("Informe o segundo numero:"))
c = Number(prompt("informe o terceiro numero"))

media= (a+b+c)/3

alert(`A média é ${media}`)