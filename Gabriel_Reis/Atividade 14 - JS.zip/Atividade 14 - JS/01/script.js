function abreLink(){
    window. open("http://google.com.br", "_blank")
}
