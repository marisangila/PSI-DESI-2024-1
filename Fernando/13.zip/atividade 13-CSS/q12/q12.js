cHealth=10

function atacar() {
    if (cHealth!=0){
        cHealth=cHealth-1
    }


}