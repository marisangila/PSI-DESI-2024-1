function showAlert() {
    alert("João é o melhor aluno da sala.");
}
