function abrirGoogle(){
    window.open("https://google.com.br", "_blank")
}