base = Number(prompt("Informe a base: "))
expoente = Number(prompt("Informe o expoente: "))

resultado = base**expoente
alert(`O valor do cálculo: ${base} elevado a ${expoente} é igual a ${resultado}`)