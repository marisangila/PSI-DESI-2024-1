a = Number(prompt("Informe o primeiro número: "))
b = Number(prompt("Informe o segundo número: "))
c = Number(prompt("Informe o terceiro número: "))

media = (a + b + c)/3
alert(`A média aritmética entre os números ${a}, ${b} e ${c} é: ${media}`)