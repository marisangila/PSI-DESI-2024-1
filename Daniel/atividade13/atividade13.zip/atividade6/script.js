let weight = Number(prompt(`Enter your weight:`))
let height = Number(prompt(`Enter your height:`))

IMC = weight/(height ** 2)
alert(` Your IMC is ${IMC.toFixed(2)}`)




