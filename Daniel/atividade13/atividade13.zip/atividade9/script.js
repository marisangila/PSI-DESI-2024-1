let base = Number(prompt("Enter the base of potentiation:"))
let exponent = Number(prompt("Enter the exponent this operation: "))

alert(`The result is ${base**exponent}`)







