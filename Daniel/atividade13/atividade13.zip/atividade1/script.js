let nome = prompt("Enter your name below:")
alert(`Hello ${nome}, good morning!`)