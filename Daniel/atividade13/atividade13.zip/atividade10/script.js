let number = Number(prompt("Enter a number: "))

let multiplicationTable = ""
for(i=1;i<11;i++){
    multiplicationTable += `${number*i} `
}

alert(`The multiplication table: \n${multiplicationTable}`)






