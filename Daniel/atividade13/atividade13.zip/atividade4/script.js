let age = Number(prompt('Enter your age bellow:'))

let result = age >= 18 ? "You are a gratest!!" : "You are a minor!!"
alert(`${result}`)

