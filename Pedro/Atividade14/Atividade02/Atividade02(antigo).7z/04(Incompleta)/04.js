const idade = document.getElementById("idade")

const sobrenome = document.getElementById("sobrenome").value

const nome = document.getElementById("nome").value

nome.addEventListener("change", () => valueNone(nome))

sobrenome.addEventListener("change",()=> valueNone(sobrenome))

idade.addEventListener("change",()=> valueNone(idade))

function valueNone(atributo)
{
    if(atributo == "")
    {
        alerta = document.createElement("label")
        alerta.setAttribute("id","alerta")
        alerta.textContent = "Não é permitido enviar nada";
    }
}