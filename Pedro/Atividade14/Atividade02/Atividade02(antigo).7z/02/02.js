function menu()
{
    let x= document.getElementById("menu")
    if (x.hidden === true) {
        x.hidden = false;
    } else {
        x.hidden = true;
    }
}
