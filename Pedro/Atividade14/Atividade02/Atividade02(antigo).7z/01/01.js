function proxima_pagina()
{
    window.open("http://google.com.br", "_blank")
}