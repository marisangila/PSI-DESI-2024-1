function btnClick(){
    alert('Opa, você me clicou!')
}