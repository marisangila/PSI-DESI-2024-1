function abrirGoogle(){
    open('http://google.com.br', '_blank')
}