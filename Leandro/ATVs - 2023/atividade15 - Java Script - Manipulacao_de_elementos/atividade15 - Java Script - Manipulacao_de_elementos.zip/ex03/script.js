function enviaForm(){
    var text = document.getElementById('text1').value
    if(text != ''){
        document.getElementById('paragrafo').hidden = false
    }
}